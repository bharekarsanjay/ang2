 import { Component,Input } from '@angular/core';
 import {IncomeService } from '../dashboard/income/IncomeService';
 import { IncomeInterface } from '../dashboard/income/incomeInterface';
 import { MonthInterface } from './monthInterface';



// webpack html imports
//let template = require('./line-chart-demo.html');

@Component({
  selector: 'line-chart-demo',
  templateUrl: 'app/components/home/home.html',
   providers:[IncomeService]


})
export class Home { 
  // lineChart
  	@Input() monthbaseCatData;
    monthbaseCatData1:{
      data:null
    };
    totalAmt:number =0;
    public dataChart:Array<any>;
  public lineChartData:Array<any>=[];
  public lineChartData1;
 // public lineChartLabels:Array<any> =[];
  constructor( private _service:IncomeService){       
 //     this.lineChartData[i].labelData = 
   
  }
  /*
getdata() {
  return this._service.httpGetCatAllData().map(
      (users) => {
        this.monthbaseCatData1 = users;

      })
     .catch((error) => {
        console.log('error ' + error);
        throw error;
      });
    // users => this.users = users,
    // error => this.errorMsg = <any>error);
  } */
ngOnInit(){
this.lineChartData =  [
   {"data":[0,0,0,0,0,0,"180.00","252.00",0,"687.00","639.00",0],"label":"Ganpati"},
{"data":[0,0,0,0,0,"410.00","92.00","746.00",0,"217.00",0,0],"label":"Swami"},
{"data":[0,0,0,0,0,"139.00","365.00",0,"592.00",0,0,0],"label":"Mhasoba Karndak"},
{"data":["972.00",0,"312.00",0,"225.00",0,0,"1000.00","34.00","667.00","44.00",0],"label":"Rent"},
{"data":[],"label":"Other"}
  ];

  this.lineChartData = this.lineChartData.slice();

}
  ngOnChanges(){
  
  for(let x in this.monthbaseCatData){ 
    console.log( this.monthbaseCatData[x].catTotalAmt + "totalAmt data");
               this.totalAmt+= parseInt(this.monthbaseCatData[x].catTotalAmt);
                   console.log( this.totalAmt + "totalAmt ");

                       var monthData1:MonthInterface[]=[
    {    id:1,    monthName:"Jan",    totalAmt:0, data:[] },
    {    id:2,    monthName:"Feb",    totalAmt:0 , data:[] },
    {    id:3,    monthName:"Mar",    totalAmt:0 , data:[]  },
    {    id:4,    monthName:"Apr",    totalAmt:0 , data:[]  },
    {    id:5,    monthName:"May",    totalAmt:0  , data:[] },
    {    id:6,    monthName:"Jun",    totalAmt:0 , data:[]  },
    {    id:7,    monthName:"Jul",    totalAmt:0 , data:[]  },
    {    id:8,    monthName:"Aug",    totalAmt:0 , data:[]  },
    {    id:9,    monthName:"Sep",    totalAmt:0 , data:[]  },
    {    id:10,    monthName:"Oct",    totalAmt:0 , data:[]  },
    {    id:11,    monthName:"Nov",    totalAmt:0 , data:[]  },
    {    id:12,    monthName:"Dec",    totalAmt:0 , data:[]  }   
    
    ] ;


                   for(let y in this.monthbaseCatData[x].catData)
                   {
                     ;
                       var a= this.monthbaseCatData[x].catData[y].receivedDate;
                        var bb = a.split("-");
                        var aa = parseInt(bb[1]);
                        switch (aa) {
    case 1:
      monthData1[0].totalAmt = this.monthbaseCatData[x].catData[y].receiptAmt;
      monthData1[0].data.push(this.monthbaseCatData[x].catData[y]);
        break;
    case 2:
         monthData1[1].totalAmt+=  this.monthbaseCatData[x].catData[y].receiptAmt;
         monthData1[1].data.push(this.monthbaseCatData[x].catData[y]);
        break;
   

    case 3:
         monthData1[2].totalAmt = this.monthbaseCatData[x].catData[y].receiptAmt;
      monthData1[2].data.push(this.monthbaseCatData[x].catData[y]);
        break;
   
    case 4:
          monthData1[3].totalAmt = this.monthbaseCatData[x].catData[y].receiptAmt;
      monthData1[3].data.push(this.monthbaseCatData[x].catData[y]);
        break;
   

    case 5:
         monthData1[4].totalAmt = this.monthbaseCatData[x].catData[y].receiptAmt;
      monthData1[4].data.push(this.monthbaseCatData[x].catData[y]);
        break;
   
    case 6:
          monthData1[5].totalAmt = this.monthbaseCatData[x].catData[y].receiptAmt;
      monthData1[5].data.push(this.monthbaseCatData[x].catData[y]);
        break;
   
case 7:
         monthData1[6].totalAmt = this.monthbaseCatData[x].catData[y].receiptAmt;
      monthData1[6].data.push(this.monthbaseCatData[x].catData[y]);
        break;
   
  case 8:
            monthData1[7].totalAmt = this.monthbaseCatData[x].catData[y].receiptAmt;
      monthData1[7].data.push(this.monthbaseCatData[x].catData[y]);
        break;
   
case 9:
      monthData1[8].totalAmt = this.monthbaseCatData[x].catData[y].receiptAmt;
      monthData1[8].data.push(this.monthbaseCatData[x].catData[y]);
        break;
   
case 10:
           monthData1[9].totalAmt = this.monthbaseCatData[x].catData[y].receiptAmt;
      monthData1[9].data.push(this.monthbaseCatData[x].catData[y]);
        break;
   case 11:
            monthData1[10].totalAmt = this.monthbaseCatData[x].catData[y].receiptAmt;
      monthData1[10].data.push(this.monthbaseCatData[x].catData[y]);
        break;
   
case 12:
            monthData1[11].totalAmt = this.monthbaseCatData[x].catData[y].receiptAmt;
      monthData1[11].data.push(this.monthbaseCatData[x].catData[y]);
        break;
   


}

                   }

                   this.monthbaseCatData[x].monthData = monthData1;
    }
      console.log( this.monthbaseCatData);

       for(let z in this.monthbaseCatData)
 {
    var obj = {data:[],label:""};
    let self = this;

    for(let a in self.monthbaseCatData[z].monthData){
        obj.data.push(Math.round(self.monthbaseCatData[z].monthData[a].totalAmt));
      
    }
    
 //  obj.label=self.monthbaseCatData[z].catName;
  self.lineChartData[z].data = (obj.data);  

  
 }
 console.log("Obj lineChart"+JSON.stringify(this.lineChartData));
  console.log("Obj lineChart"+JSON.stringify(this.lineChartData2));
 console.log(this.lineChartData);
  console.log(this.lineChartData2);
 this.lineChartData= this.lineChartData.slice();
  }


  public lineChartData2 = [
    {data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A'},
    {data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B'},
    {data: [18, 48, 77, 9, 100, 27, 40], label: 'Series C'}
  ];
  

  

  /*= [

{"data":[0,0,0,0,0,0,"180.00","252.00",0,"687.00","639.00",0],"lable":"Ganpati"},
{"data":[0,0,0,0,0,"410.00","92.00","746.00",0,"217.00",0,0],"lable":"Swami"},
{"data":[0,0,0,0,0,"139.00","365.00",0,"592.00",0,0,0],"lable":"Mhasoba Karndak"},
{"data":["972.00",0,"312.00",0,"225.00",0,0,"1000.00","34.00","667.00","44.00",0],"lable":"Rent"},
{"data":[],"lable":"Other"}

];*/





  public lineChartLabels:Array<any> = ['January', 'February', 'March', 'April', 'May', 'June', 'July','Aug','Sept','Oct','Nov','Dec'];

  public lineChartOptions:any = {
    animation: false,
    responsive: true
  };
  public lineChartColors:Array<any> = [
    { // grey
      backgroundColor: 'rgba(148,159,177,0.2)',
      borderColor: 'rgba(148,159,177,1)',
      pointBackgroundColor: 'rgba(148,159,177,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(148,159,177,0.8)'
    },
    { // dark grey
      backgroundColor: 'rgba(77,83,96,0.2)',
      borderColor: 'rgba(77,83,96,1)',
      pointBackgroundColor: 'rgba(77,83,96,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(77,83,96,1)'
    },
    { // grey
      backgroundColor: 'rgba(148,159,177,0.2)',
      borderColor: 'rgba(148,159,177,1)',
      pointBackgroundColor: 'rgba(148,159,177,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(148,159,177,0.8)'
    }
  ];
  public lineChartLegend:boolean = true;
  public lineChartType:string = 'line';

  public randomize():void {
    let _lineChartData:Array<any> = new Array(this.lineChartData.length);
    for (let i = 0; i < this.lineChartData.length; i++) {
      _lineChartData[i] = {data: new Array(this.lineChartData[i].data.length), label: this.lineChartData[i].label};
      for (let j = 0; j < this.lineChartData[i].data.length; j++) {
        _lineChartData[i].data[j] = Math.floor((Math.random() * 100) + 1);
      }
    }
    this.lineChartData = _lineChartData;
  }

  // events
  public chartClicked(e:any):void {
    console.log(e);
  }

  public chartHovered(e:any):void {
    console.log(e);
  }
}

