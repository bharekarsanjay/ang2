 import { Component } from '@angular/core';
  import {IncomeService } from './income/IncomeService';
  import {IncomeInterface } from './income/incomeInterface'; 
import 'rxjs/Rx';

@Component({
  selector: 'fb-dashboard',
  templateUrl: 'app/components/dashboard/dashboard.html',
    providers:[IncomeService],

})
export class Dashboard {
  mainCatData = {};
  mainAllCatData;
  totalAmt;


  constructor( private _service:IncomeService){
 
      
  }
getData(){
return this._service.httpGetCatAllData().map(
      (users) => {
        this.mainAllCatData = users;
      })
     .catch((error) => {
        console.log('error ' + error);
        throw error;
      });

}
ngOnInit(){
  this.getData().subscribe(_ => {
     this.mainAllCatData = this.mainAllCatData  ;
    /*
 for(let x in this.mainAllCatData){ 
               this.totalAmt+= parseInt(this.mainAllCatData[x].catTotalAmt);
           console.log(this.totalAmt);

    }
*/
    });
}

 }

