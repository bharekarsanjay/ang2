 import { Component,Output,EventEmitter, Input } from '@angular/core';
 import { Observable } from 'rxjs/Observable';
import {Observer} from 'rxjs/Observer';

 import {IncomeService } from './IncomeService';
 import { IncomeInterface } from './incomeInterface';

@Component({
  selector: 'fb-income',
  templateUrl: 'app/components/dashboard/income/income.html',
  providers:[IncomeService],

})
export class Income { 
@Input() incomeCatData;

 @Output() onSendData = new EventEmitter()
public totalAmt:number=0; 
  public mainAllCatData;
 constructor(public _service:IncomeService){   }

 
 
 ngOnChanges() {

   for(let x in this.incomeCatData){ 
               this.totalAmt+= parseInt(this.incomeCatData[x].catTotalAmt);

    }
   
 /*   this.getdata().subscribe(_ => {;
      console.log('ngOnit after getUsers() ' + this.mainAllCatData);
 for(let x in this.mainAllCatData){ 
     console.log(this.mainAllCatData[x].catTotalAmt)
               this.totalAmt+= parseInt(this.mainAllCatData[x].catTotalAmt);
           console.log(this.totalAmt);

    }

    }); */
   
}

}