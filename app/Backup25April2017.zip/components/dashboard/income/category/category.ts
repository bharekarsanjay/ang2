import { Component } from '@angular/core';
  import {IncomeService } from './../IncomeService';
  import {IncomeInterface } from './../incomeInterface'; 
  import { ActivatedRoute } from '@angular/router';
import 'rxjs/Rx';

@Component({
  selector: 'fb-dashboard',
  templateUrl: 'app/components/dashboard/income/category/Category.html',
    providers:[IncomeService],

})
export class Category {

  catData;
  totalAmt;
 id: number;
  private sub: any;

  constructor( private _service:IncomeService ,private route: ActivatedRoute) {}
getData(){
return this._service.httpGetCatAllData().map(
      (data) => {
          for(let x in data)
           {
               if(this.id===data[x].catid)
                {
                    this.catData=data[x];
                }
          }

       
      })
     .catch((error) => {
        console.log('error ' + error);
        throw error;
      });

}
  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
       this.id = +params['id']; // (+) converts string 'id' to a number

       // In a real app: dispatch action to load the details here.
      
    });
   this.getData().subscribe(_ => {
     this.catData = this.catData  ;
     console.log(this.catData);
   });

  }
  
}