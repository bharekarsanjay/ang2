"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var IncomeService_1 = require('./../IncomeService');
var router_1 = require('@angular/router');
require('rxjs/Rx');
var Category = (function () {
    function Category(_service, route) {
        this._service = _service;
        this.route = route;
    }
    Category.prototype.getData = function () {
        var _this = this;
        return this._service.httpGetCatAllData().map(function (data) {
            for (var x in data) {
                if (_this.id === data[x].catid) {
                    _this.catData = data[x];
                }
            }
        })
            .catch(function (error) {
            console.log('error ' + error);
            throw error;
        });
    };
    Category.prototype.ngOnInit = function () {
        var _this = this;
        this.sub = this.route.params.subscribe(function (params) {
            _this.id = +params['id']; // (+) converts string 'id' to a number
            // In a real app: dispatch action to load the details here.
        });
        this.getData().subscribe(function (_) {
            _this.catData = _this.catData;
            console.log(_this.catData);
        });
    };
    Category = __decorate([
        core_1.Component({
            selector: 'fb-dashboard',
            templateUrl: 'app/components/dashboard/income/category/Category.html',
            providers: [IncomeService_1.IncomeService],
        }), 
        __metadata('design:paramtypes', [IncomeService_1.IncomeService, router_1.ActivatedRoute])
    ], Category);
    return Category;
}());
exports.Category = Category;
//# sourceMappingURL=category.js.map