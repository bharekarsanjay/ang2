"use strict";
//# sourceMappingURL=IncomeInterface.js.map