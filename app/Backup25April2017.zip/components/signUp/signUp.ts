 import { Component } from '@angular/core';
@Component({
  selector: 'fb-signup',
  templateUrl: 'app/components/SignUp/signUp.html'
})
export class SignUp { }

