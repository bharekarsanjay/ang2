import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule }   from '@angular/router';
 import { ChartsModule } from 'ng2-charts/ng2-charts';
 import {HttpModule} from '@angular/http';


import { AppComponent }   from './app.component';
import {SignUp } from './components/signUp/signUp';
 import {Home} from './components/home/home';
import {Login } from './components/login/login';
import {Dashboard } from './components/dashboard/dashboard';
import{Category} from './components/dashboard/income/category/category'
import {Income} from './components/dashboard/income/income';
import { IncomeService } from './components/dashboard/income/incomeService';
@NgModule({
  imports:      [ BrowserModule,ChartsModule,HttpModule,RouterModule.forRoot([
      {
        path: 'signUp',
        component: SignUp
      },
      {
        path: '',
        component: Login
      },
      {
        path: 'login',
        component: Login
      },{
        path: 'dashboard',
        component: Dashboard
      },{
        path: 'category/:id',
        component: Category
      }

    ]) ],
    providers:[IncomeService],
  declarations: [ AppComponent ,SignUp,Login,Dashboard,Income ,Home,Category],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
